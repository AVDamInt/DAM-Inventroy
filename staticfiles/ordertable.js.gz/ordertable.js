$(document).ready(function () {
  $('#sortedtable').DataTable();
  document.getElementById("sortedtable_length").style.visibility = "hidden";
  document.getElementById("sortedtable_paginate").style.visibility = "hidden";
  document.getElementById("sortedtable_info").style.visibility = "hidden";
  document.getElementById("sortedtable_filter").style.visibility = "hidden";
});